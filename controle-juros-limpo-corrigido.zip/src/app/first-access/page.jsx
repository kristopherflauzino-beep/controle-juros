'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function FirstAccessPage() {
  const router = useRouter();
  const [available, setAvailable] = useState(null);
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetch('/api/auth/first-access').then(r => r.json()).then(data => setAvailable(Boolean(data.available))).catch(() => setAvailable(false));
  }, []);

  async function submit(e) {
    e.preventDefault();
    setLoading(true);
    setMessage('');
    const response = await fetch('/api/auth/first-access', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    });
    const data = await response.json();
    setLoading(false);
    if (!response.ok) {
      setMessage(data.error || 'Erro ao cadastrar administrador.');
      return;
    }
    router.push('/admin');
  }

  return (
    <main className="authPage">
      <section className="authBrand">
        <div className="logoMark">CJ</div>
        <h1>Primeiro acesso</h1>
        <p>Cadastre o administrador inicial. Depois desse cadastro, esta tela fica bloqueada.</p>
      </section>
      <section className="authCard">
        <h2>Administrador inicial</h2>
        {available === false ? (
          <>
            <p>O administrador inicial já foi cadastrado.</p>
            <Link href="/login">Voltar para login</Link>
          </>
        ) : (
          <form className="formGrid" onSubmit={submit}>
            <label className="field"><span>Nome</span><input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required /></label>
            <label className="field"><span>E-mail/Login</span><input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required /></label>
            <label className="field"><span>Senha</span><input type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} required /></label>
            <button className="primary" disabled={loading}>{loading ? 'Salvando...' : 'Cadastrar administrador'}</button>
          </form>
        )}
        {message && <div className="message error">{message}</div>}
      </section>
    </main>
  );
}
