import { calculatePriceTable } from '@/lib/finance';
import { errorResponse, json, readJson } from '@/lib/http';

export async function POST(request) {
  try {
    const body = await readJson(request);
    const result = calculatePriceTable({
      principal: Number(body.principal),
      rate: Number(body.rate || 0),
      installments: Number(body.installments),
      firstDueDate: body.firstDueDate
    });
    return json(result);
  } catch (error) {
    return errorResponse(error);
  }
}
