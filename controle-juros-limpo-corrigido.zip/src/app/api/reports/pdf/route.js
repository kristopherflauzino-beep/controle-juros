import PDFDocument from 'pdfkit';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/auth';
import { calculateDailyInterest, formatMoney } from '@/lib/finance';
import { errorResponse } from '@/lib/http';

function bufferPdf({ title, agreements }) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ margin: 42, size: 'A4' });
    const chunks = [];
    doc.on('data', chunk => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    doc.fontSize(20).text('Controle de Juros', { align: 'center' });
    doc.moveDown(.3).fontSize(12).text(title, { align: 'center' });
    doc.moveDown().fontSize(10).text(`Data de emissão: ${new Date().toLocaleString('pt-BR')}`);
    doc.moveDown();

    agreements.forEach((agreement, idx) => {
      if (idx > 0) doc.moveDown();
      if (doc.y > 720) doc.addPage();
      const updated = calculateDailyInterest({
        openValue: Number(agreement.totalFinal),
        dailyRate: Number(agreement.dailyInterestRate),
        startedAt: agreement.dailyInterestStartedAt
      });
      doc.fontSize(12).font('Helvetica-Bold').text(`${idx + 1}. ${agreement.client.name}`);
      doc.font('Helvetica').fontSize(9)
        .text(`Valor original: ${formatMoney(agreement.originalValue)} | Parcelas: ${agreement.installmentsCount} | Juros: ${Number(agreement.interestRate).toLocaleString('pt-BR')}%`)
        .text(`Total final: ${formatMoney(agreement.totalFinal)} | Atualizado: ${formatMoney(updated.updatedValue)} | Status: ${agreement.status}`)
        .text(`Juros diário: ${Number(agreement.dailyInterestRate).toLocaleString('pt-BR')}% | Início: ${agreement.dailyInterestStartedAt ? new Date(agreement.dailyInterestStartedAt).toLocaleDateString('pt-BR') : 'Não iniciado'}`)
        .text(`Observações: ${agreement.notes || '-'}`);
    });

    doc.end();
  });
}

export async function GET(request) {
  try {
    await requireAdmin();
    const { searchParams } = new URL(request.url);
    const clientId = searchParams.get('clientId');
    const where = clientId ? { clientId } : {};
    const agreements = await prisma.agreement.findMany({
      where,
      include: { client: true, installments: { orderBy: { number: 'asc' } } },
      orderBy: { createdAt: 'desc' }
    });

    const title = clientId ? 'Relatórios por cliente' : 'Relatório geral administrativo';
    const buffer = await bufferPdf({ title, agreements });
    return new Response(buffer, {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="relatorio-geral-controle-juros.pdf"`
      }
    });
  } catch (error) {
    return errorResponse(error);
  }
}
