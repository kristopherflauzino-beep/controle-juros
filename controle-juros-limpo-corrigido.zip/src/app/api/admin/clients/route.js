import { prisma } from '@/lib/prisma';
import { requireAdmin, hashPassword } from '@/lib/auth';
import { errorResponse, json, readJson, serializeClient } from '@/lib/http';

export async function GET() {
  try {
    await requireAdmin();
    const clients = await prisma.client.findMany({
      include: { user: true, agreements: true, requests: true },
      orderBy: { createdAt: 'desc' }
    });
    return json({ clients: clients.map(serializeClient) });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request) {
  try {
    await requireAdmin();
    const body = await readJson(request);
    const name = String(body.name || '').trim();
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');

    if (!name) return json({ error: 'Cliente sem nome não é permitido.' }, 400);
    if (!email) return json({ error: 'Cliente sem login/e-mail não é permitido.' }, 400);
    if (!password) return json({ error: 'Senha inicial não pode ser vazia.' }, 400);

    const exists = await prisma.user.findUnique({ where: { email } });
    if (exists) return json({ error: 'Já existe usuário com este e-mail/login.' }, 409);

    const client = await prisma.client.create({
      data: {
        name,
        email,
        cpfCnpj: body.cpfCnpj ? String(body.cpfCnpj).trim() : null,
        phone: body.phone ? String(body.phone).trim() : null,
        active: body.active !== false,
        user: {
          create: {
            name,
            email,
            passwordHash: await hashPassword(password),
            role: 'CLIENT',
            active: body.active !== false
          }
        }
      },
      include: { user: true }
    });

    return json({ client: serializeClient(client) }, 201);
  } catch (error) {
    return errorResponse(error);
  }
}
