import { prisma } from '@/lib/prisma';
import { requireAdmin, hashPassword } from '@/lib/auth';
import { errorResponse, json, readJson, serializeClient } from '@/lib/http';

export async function PUT(request, { params }) {
  try {
    await requireAdmin();
    const body = await readJson(request);
    const name = String(body.name || '').trim();
    const email = String(body.email || '').trim().toLowerCase();

    if (!name) return json({ error: 'Cliente sem nome não é permitido.' }, 400);
    if (!email) return json({ error: 'Cliente sem login/e-mail não é permitido.' }, 400);

    const current = await prisma.client.findUnique({ where: { id: params.id }, include: { user: true } });
    if (!current) return json({ error: 'Cliente não encontrado.' }, 404);

    const active = body.active !== false;
    const userData = {
      name,
      email,
      active
    };
    if (body.password) userData.passwordHash = await hashPassword(String(body.password));

    const client = await prisma.client.update({
      where: { id: params.id },
      data: {
        name,
        email,
        cpfCnpj: body.cpfCnpj ? String(body.cpfCnpj).trim() : null,
        phone: body.phone ? String(body.phone).trim() : null,
        active,
        user: { update: userData }
      },
      include: { user: true }
    });

    return json({ client: serializeClient(client) });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function DELETE(_request, { params }) {
  try {
    await requireAdmin();
    const current = await prisma.client.findUnique({ where: { id: params.id }, include: { user: true } });
    if (!current) return json({ ok: true });
    await prisma.user.delete({ where: { id: current.userId } });
    return json({ ok: true });
  } catch (error) {
    return errorResponse(error);
  }
}
