import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/auth';
import { calculateDailyInterest } from '@/lib/finance';
import { errorResponse, json, serializeRequest } from '@/lib/http';

export async function GET() {
  try {
    await requireAdmin();
    const [clients, pendingRequests, agreements, lateReports, latestRequests] = await Promise.all([
      prisma.client.count(),
      prisma.request.count({ where: { status: 'PENDENTE' } }),
      prisma.agreement.findMany({ include: { client: true } }),
      prisma.agreement.count({ where: { status: 'ATRASADO' } }),
      prisma.request.findMany({ orderBy: { createdAt: 'desc' }, take: 6, include: { client: true } })
    ]);

    const totalOpen = agreements
      .filter(item => item.status === 'ABERTO' || item.status === 'ATRASADO')
      .reduce((sum, item) => sum + Number(item.totalFinal), 0);

    const totalUpdated = agreements
      .filter(item => item.status === 'ABERTO' || item.status === 'ATRASADO')
      .reduce((sum, item) => sum + calculateDailyInterest({
        openValue: Number(item.totalFinal),
        dailyRate: Number(item.dailyInterestRate),
        startedAt: item.dailyInterestStartedAt
      }).updatedValue, 0);

    return json({
      totalClients: clients,
      pendingRequests,
      totalOpen,
      totalUpdated,
      lateReports,
      latestRequests: latestRequests.map(item => ({ ...serializeRequest(item), client: item.client }))
    });
  } catch (error) {
    return errorResponse(error);
  }
}
