import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/auth';
import { calculatePriceTable } from '@/lib/finance';
import { errorResponse, json, readJson, serializeAgreement } from '@/lib/http';

export async function POST(request, { params }) {
  try {
    await requireAdmin();
    const body = await readJson(request);
    const req = await prisma.request.findUnique({ where: { id: params.id }, include: { client: true } });
    if (!req) return json({ error: 'Solicitação não encontrada.' }, 404);

    const principal = Number(body.originalValue || req.amount);
    const installmentsCount = Number(body.installmentsCount || 1);
    const interestRate = Number(body.interestRate || 0);
    const dailyInterestRate = Number(body.dailyInterestRate || 0);
    const dueDate = body.dueDate ? new Date(body.dueDate) : new Date();

    const price = calculatePriceTable({ principal, rate: interestRate, installments: installmentsCount, firstDueDate: dueDate });

    const agreement = await prisma.$transaction(async tx => {
      await tx.request.update({ where: { id: req.id }, data: { status: 'APROVADO' } });
      return tx.agreement.create({
        data: {
          clientId: req.clientId,
          requestId: req.id,
          originalValue: price.principal,
          installmentsCount,
          interestRate,
          installmentValue: price.installmentValue,
          totalFinal: price.totalFinal,
          dueDate,
          dailyInterestRate,
          status: 'ABERTO',
          notes: body.notes ? String(body.notes) : req.observation,
          installments: {
            create: price.table.map(item => ({
              number: item.number,
              value: item.value,
              interest: item.interest,
              amortization: item.amortization,
              balance: item.balance,
              dueDate: item.dueDate
            }))
          }
        },
        include: { client: true, installments: true }
      });
    });

    return json({ agreement: serializeAgreement(agreement) });
  } catch (error) {
    return errorResponse(error);
  }
}
