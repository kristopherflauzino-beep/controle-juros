import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/auth';
import { errorResponse, json } from '@/lib/http';

export async function POST(_request, { params }) {
  try {
    await requireAdmin();
    const item = await prisma.request.update({ where: { id: params.id }, data: { status: 'RECUSADO' } });
    return json({ request: { ...item, amount: Number(item.amount) } });
  } catch (error) {
    return errorResponse(error);
  }
}
