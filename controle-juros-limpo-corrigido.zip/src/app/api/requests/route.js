import { prisma } from '@/lib/prisma';
import { requireAdmin, requireClient } from '@/lib/auth';
import { errorResponse, json, readJson, serializeRequest } from '@/lib/http';

export async function GET() {
  try {
    await requireAdmin();
    const requests = await prisma.request.findMany({
      include: { client: true },
      orderBy: { createdAt: 'desc' }
    });
    return json({ requests: requests.map(item => ({ ...serializeRequest(item), client: item.client })) });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request) {
  try {
    const user = await requireClient();
    const body = await readJson(request);
    const amount = Number(body.amount);
    if (!Number.isFinite(amount) || amount <= 0) return json({ error: 'Informe valor solicitado maior que zero.' }, 400);

    const item = await prisma.request.create({
      data: {
        clientId: user.client.id,
        amount,
        observation: body.observation ? String(body.observation).trim() : null,
        status: 'PENDENTE'
      },
      include: { client: true }
    });

    return json({ request: { ...serializeRequest(item), client: item.client } }, 201);
  } catch (error) {
    return errorResponse(error);
  }
}
