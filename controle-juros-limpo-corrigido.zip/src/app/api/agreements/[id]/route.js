import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/auth';
import { calculatePriceTable } from '@/lib/finance';
import { errorResponse, json, readJson, serializeAgreement } from '@/lib/http';

export async function PUT(request, { params }) {
  try {
    await requireAdmin();
    const body = await readJson(request);
    const current = await prisma.agreement.findUnique({ where: { id: params.id } });
    if (!current) return json({ error: 'Relatório não encontrado.' }, 404);

    const principal = Number(body.originalValue);
    const installmentsCount = Number(body.installmentsCount);
    const interestRate = Number(body.interestRate || 0);
    const dailyInterestRate = Number(body.dailyInterestRate || 0);
    const dueDate = body.dueDate ? new Date(body.dueDate) : null;

    if (!Number.isFinite(principal) || principal <= 0) return json({ error: 'Valor deve ser maior que zero.' }, 400);
    if (!Number.isInteger(installmentsCount) || installmentsCount < 1) return json({ error: 'Parcelas deve ser maior ou igual a 1.' }, 400);
    if (!Number.isFinite(interestRate) || interestRate < 0) return json({ error: 'Taxa de juros inválida.' }, 400);
    if (!Number.isFinite(dailyInterestRate) || dailyInterestRate < 0) return json({ error: 'Juros diário inválido.' }, 400);
    if (!dueDate || Number.isNaN(dueDate.getTime())) return json({ error: 'Informe o vencimento.' }, 400);

    const price = calculatePriceTable({ principal, rate: interestRate, installments: installmentsCount, firstDueDate: dueDate });

    const agreement = await prisma.$transaction(async tx => {
      await tx.installment.deleteMany({ where: { agreementId: params.id } });
      return tx.agreement.update({
        where: { id: params.id },
        data: {
          originalValue: price.principal,
          installmentsCount,
          interestRate,
          installmentValue: price.installmentValue,
          totalFinal: price.totalFinal,
          dueDate,
          dailyInterestRate,
          status: body.status || current.status,
          notes: body.notes ? String(body.notes) : null,
          dailyInterestStartedAt: current.dailyInterestStartedAt,
          installments: {
            create: price.table.map(item => ({
              number: item.number,
              value: item.value,
              interest: item.interest,
              amortization: item.amortization,
              balance: item.balance,
              dueDate: item.dueDate
            }))
          }
        },
        include: { client: true, installments: { orderBy: { number: 'asc' } } }
      });
    });

    return json({ agreement: serializeAgreement(agreement) });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function DELETE(_request, { params }) {
  try {
    await requireAdmin();
    await prisma.agreement.delete({ where: { id: params.id } });
    return json({ ok: true });
  } catch (error) {
    return errorResponse(error);
  }
}
