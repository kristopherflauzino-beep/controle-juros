import PDFDocument from 'pdfkit';
import { prisma } from '@/lib/prisma';
import { requireUser } from '@/lib/auth';
import { calculateDailyInterest, formatMoney } from '@/lib/finance';
import { errorResponse } from '@/lib/http';

function makePdfBuffer(agreement) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ margin: 42, size: 'A4' });
    const chunks = [];
    doc.on('data', chunk => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    const updated = calculateDailyInterest({
      openValue: Number(agreement.totalFinal),
      dailyRate: Number(agreement.dailyInterestRate),
      startedAt: agreement.dailyInterestStartedAt
    });

    doc.fontSize(20).text('Controle de Juros', { align: 'center' });
    doc.moveDown(.3).fontSize(12).text('Relatório / Acordo Financeiro', { align: 'center' });
    doc.moveDown();
    doc.fontSize(10).text(`Data de emissão: ${new Date().toLocaleString('pt-BR')}`);
    doc.moveDown();

    doc.fontSize(13).text('Dados do Cliente', { underline: true });
    doc.fontSize(10)
      .text(`Nome: ${agreement.client.name}`)
      .text(`CPF/CNPJ: ${agreement.client.cpfCnpj || '-'}`)
      .text(`Telefone: ${agreement.client.phone || '-'}`)
      .text(`E-mail/Login: ${agreement.client.email}`);
    doc.moveDown();

    doc.fontSize(13).text('Dados do Acordo', { underline: true });
    doc.fontSize(10)
      .text(`Valor original: ${formatMoney(agreement.originalValue)}`)
      .text(`Parcelas: ${agreement.installmentsCount}`)
      .text(`Juros por período: ${Number(agreement.interestRate).toLocaleString('pt-BR')}%`)
      .text(`Valor da parcela: ${formatMoney(agreement.installmentValue)}`)
      .text(`Total final: ${formatMoney(agreement.totalFinal)}`)
      .text(`Data do acordo: ${new Date(agreement.agreementDate).toLocaleDateString('pt-BR')}`)
      .text(`Vencimento: ${new Date(agreement.dueDate).toLocaleDateString('pt-BR')}`)
      .text(`Status: ${agreement.status}`)
      .text(`Observações: ${agreement.notes || '-'}`);
    doc.moveDown();

    doc.fontSize(13).text('Juros Diário', { underline: true });
    doc.fontSize(10)
      .text(`Juros diário aplicado: ${Number(agreement.dailyInterestRate).toLocaleString('pt-BR')}%`)
      .text(`Data de início do juros: ${agreement.dailyInterestStartedAt ? new Date(agreement.dailyInterestStartedAt).toLocaleString('pt-BR') : 'Não iniciado'}`)
      .text(`Dias de juros: ${updated.days}`)
      .text(`Juros acumulado: ${formatMoney(updated.accumulatedInterest)}`)
      .text(`Valor atualizado: ${formatMoney(updated.updatedValue)}`);
    doc.moveDown();

    doc.fontSize(13).text('Tabela de Parcelas', { underline: true });
    doc.moveDown(.5);
    const startX = doc.x;
    let y = doc.y;
    const columns = [35, 82, 82, 92, 92, 92];
    const headers = ['Nº', 'Parcela', 'Juros', 'Amortização', 'Saldo', 'Vencimento'];
    doc.fontSize(8).font('Helvetica-Bold');
    headers.forEach((h, idx) => doc.text(h, startX + columns.slice(0, idx).reduce((a,b)=>a+b,0), y, { width: columns[idx] }));
    y += 16;
    doc.font('Helvetica');
    agreement.installments.forEach(item => {
      if (y > 760) { doc.addPage(); y = 42; }
      const values = [
        item.number,
        formatMoney(item.value),
        formatMoney(item.interest),
        formatMoney(item.amortization),
        formatMoney(item.balance),
        item.dueDate ? new Date(item.dueDate).toLocaleDateString('pt-BR') : '-'
      ];
      values.forEach((v, idx) => doc.text(String(v), startX + columns.slice(0, idx).reduce((a,b)=>a+b,0), y, { width: columns[idx] }));
      y += 14;
    });

    doc.end();
  });
}

export async function GET(_request, { params }) {
  try {
    const user = await requireUser();
    const agreement = await prisma.agreement.findUnique({
      where: { id: params.id },
      include: { client: true, installments: { orderBy: { number: 'asc' } } }
    });
    if (!agreement) return new Response('Relatório não encontrado.', { status: 404 });
    if (user.role !== 'ADMIN' && agreement.clientId !== user.client.id) return new Response('Acesso negado.', { status: 403 });

    const buffer = await makePdfBuffer(agreement);
    return new Response(buffer, {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="relatorio-${agreement.id}.pdf"`
      }
    });
  } catch (error) {
    return errorResponse(error);
  }
}
