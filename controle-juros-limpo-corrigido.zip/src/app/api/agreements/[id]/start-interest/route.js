import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/auth';
import { errorResponse, json, serializeAgreement } from '@/lib/http';

export async function POST(_request, { params }) {
  try {
    await requireAdmin();
    const current = await prisma.agreement.findUnique({ where: { id: params.id } });
    if (!current) return json({ error: 'Relatório não encontrado.' }, 404);

    const startedAt = current.dailyInterestStartedAt || new Date();
    const agreement = await prisma.agreement.update({
      where: { id: params.id },
      data: {
        dailyInterestStartedAt: startedAt,
        dailyInterestLogs: current.dailyInterestStartedAt ? undefined : {
          create: { startedAt, dailyRate: current.dailyInterestRate }
        }
      },
      include: { client: true, installments: { orderBy: { number: 'asc' } } }
    });

    return json({ agreement: serializeAgreement(agreement) });
  } catch (error) {
    return errorResponse(error);
  }
}
