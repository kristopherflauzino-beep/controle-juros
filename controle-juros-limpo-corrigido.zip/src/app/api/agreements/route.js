import { prisma } from '@/lib/prisma';
import { requireAdmin, requireUser } from '@/lib/auth';
import { calculatePriceTable } from '@/lib/finance';
import { errorResponse, json, readJson, serializeAgreement } from '@/lib/http';

export async function GET(request) {
  try {
    const user = await requireUser();
    const { searchParams } = new URL(request.url);
    const clientId = searchParams.get('clientId');

    const where = user.role === 'ADMIN'
      ? (clientId ? { clientId } : {})
      : { clientId: user.client.id };

    const agreements = await prisma.agreement.findMany({
      where,
      include: { client: true, installments: { orderBy: { number: 'asc' } } },
      orderBy: { createdAt: 'desc' }
    });

    return json({ agreements: agreements.map(serializeAgreement) });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request) {
  try {
    await requireAdmin();
    const body = await readJson(request);
    const clientId = String(body.clientId || '');
    const principal = Number(body.originalValue);
    const installmentsCount = Number(body.installmentsCount);
    const interestRate = Number(body.interestRate || 0);
    const dailyInterestRate = Number(body.dailyInterestRate || 0);
    const dueDate = body.dueDate ? new Date(body.dueDate) : null;

    if (!clientId) return json({ error: 'Selecione um cliente.' }, 400);
    if (!Number.isFinite(principal) || principal <= 0) return json({ error: 'Valor deve ser maior que zero.' }, 400);
    if (!Number.isInteger(installmentsCount) || installmentsCount < 1) return json({ error: 'Parcelas deve ser maior ou igual a 1.' }, 400);
    if (!Number.isFinite(interestRate) || interestRate < 0) return json({ error: 'Taxa de juros inválida.' }, 400);
    if (!Number.isFinite(dailyInterestRate) || dailyInterestRate < 0) return json({ error: 'Juros diário inválido.' }, 400);
    if (!dueDate || Number.isNaN(dueDate.getTime())) return json({ error: 'Informe o vencimento.' }, 400);

    const price = calculatePriceTable({ principal, rate: interestRate, installments: installmentsCount, firstDueDate: dueDate });

    const agreement = await prisma.agreement.create({
      data: {
        clientId,
        originalValue: price.principal,
        installmentsCount,
        interestRate,
        installmentValue: price.installmentValue,
        totalFinal: price.totalFinal,
        dueDate,
        dailyInterestRate,
        status: body.status || 'ABERTO',
        notes: body.notes ? String(body.notes) : null,
        installments: {
          create: price.table.map(item => ({
            number: item.number,
            value: item.value,
            interest: item.interest,
            amortization: item.amortization,
            balance: item.balance,
            dueDate: item.dueDate
          }))
        }
      },
      include: { client: true, installments: { orderBy: { number: 'asc' } } }
    });

    return json({ agreement: serializeAgreement(agreement) }, 201);
  } catch (error) {
    return errorResponse(error);
  }
}
