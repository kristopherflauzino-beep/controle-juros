export async function GET() {
  return Response.json({ status: 'OK', service: 'Controle de Juros' });
}
