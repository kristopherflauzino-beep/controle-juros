import { prisma } from '@/lib/prisma';
import { hashPassword, signToken, setAuthCookie, safeUser } from '@/lib/auth';
import { errorResponse, json, readJson } from '@/lib/http';

export async function GET() {
  try {
    const count = await prisma.user.count({ where: { role: 'ADMIN' } });
    return json({ available: count === 0 });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request) {
  try {
    const adminCount = await prisma.user.count({ where: { role: 'ADMIN' } });
    if (adminCount > 0) return json({ error: 'Administrador inicial já foi cadastrado.' }, 409);

    const body = await readJson(request);
    const name = String(body.name || '').trim();
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');

    if (!name) return json({ error: 'Informe o nome do administrador.' }, 400);
    if (!email) return json({ error: 'Informe o e-mail/login.' }, 400);
    if (!password) return json({ error: 'Informe a senha.' }, 400);

    const user = await prisma.user.create({
      data: {
        name,
        email,
        passwordHash: await hashPassword(password),
        role: 'ADMIN',
        active: true
      }
    });

    setAuthCookie(signToken(user));
    return json({ user: safeUser(user), redirectTo: '/admin' }, 201);
  } catch (error) {
    return errorResponse(error);
  }
}
