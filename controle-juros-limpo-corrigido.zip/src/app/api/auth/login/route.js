import { prisma } from '@/lib/prisma';
import { verifyPassword, signToken, setAuthCookie, safeUser } from '@/lib/auth';
import { errorResponse, json, readJson } from '@/lib/http';

export async function POST(request) {
  try {
    const body = await readJson(request);
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');

    if (!email || !password) return json({ error: 'Informe login e senha.' }, 400);

    const user = await prisma.user.findUnique({
      where: { email },
      include: { client: true }
    });

    if (!user || !user.active || !(await verifyPassword(password, user.passwordHash))) {
      return json({ error: 'Login ou senha inválidos.' }, 401);
    }

    if (user.role === 'CLIENT' && (!user.client || !user.client.active)) {
      return json({ error: 'Cliente desativado.' }, 403);
    }

    setAuthCookie(signToken(user));
    return json({ user: safeUser(user), redirectTo: user.role === 'ADMIN' ? '/admin' : '/client' });
  } catch (error) {
    return errorResponse(error);
  }
}
