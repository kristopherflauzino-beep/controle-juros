import './globals.css';

export const metadata = {
  title: 'Controle de Juros',
  description: 'Sistema de controle de empréstimos, acordos, clientes e juros diário.'
};

export default function RootLayout({ children }) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
