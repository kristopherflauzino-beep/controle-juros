'use client';

import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';

const money = value => Number(value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const dateBR = value => value ? new Date(value).toLocaleDateString('pt-BR') : '-';

function calcDaily(totalFinal, dailyRate, startedAt) {
  const value = Number(totalFinal || 0);
  const rate = Number(dailyRate || 0);
  if (!startedAt || rate <= 0) return { days: 0, accumulated: 0, updated: value };
  const days = Math.max(0, Math.floor((Date.now() - new Date(startedAt).getTime()) / 86400000));
  const updated = value * Math.pow(1 + rate / 100, days);
  return { days, accumulated: updated - value, updated };
}

function Sidebar({ menu, setMenu, user, logout }) {
  const items = ['Solicitar valor', 'Meus relatórios', 'Meus dados'];
  return <aside className="sidebar"><div className="brand"><div className="logoMark small">CJ</div><div><strong>Controle de Juros</strong><span>Painel do cliente</span></div></div><nav>{items.map(item => <button key={item} className={menu === item ? 'active' : ''} onClick={() => setMenu(item)}>{item}</button>)}<button onClick={logout}>Sair</button></nav><div className="userBox"><strong>{user?.name}</strong><span>{user?.email}</span><span>CLIENTE</span></div></aside>;
}

function RequestValue({ setMessage }) {
  const [form, setForm] = useState({ amount: '', observation: '' });
  async function submit(e) {
    e.preventDefault();
    const res = await fetch('/api/requests', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
    const data = await res.json();
    if (!res.ok) return setMessage(data.error || 'Erro ao enviar solicitação.');
    setMessage('Solicitação enviada ao administrador.');
    setForm({ amount: '', observation: '' });
  }
  return <div className="card"><h2>Solicitar valor</h2><p>Informe o valor desejado e uma observação ou motivo da solicitação.</p><form className="formGrid" onSubmit={submit}><label className="field"><span>Valor solicitado</span><input type="number" min="0.01" step="0.01" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} required /></label><label className="field"><span>Observação / motivo</span><textarea value={form.observation} onChange={e => setForm({ ...form, observation: e.target.value })} /></label><button className="primary">Enviar solicitação</button></form></div>;
}

function Reports({ agreements }) {
  return <div className="reports">{agreements.map(a => { const daily = calcDaily(a.totalFinal, a.dailyInterestRate, a.dailyInterestStartedAt); return <div className="card" key={a.id}><div className="reportHeader"><div><h2>Relatório financeiro</h2><span className={`badge badge-${String(a.status).toLowerCase()}`}>{a.status}</span></div><button onClick={() => window.open(`/api/agreements/${a.id}/pdf`, '_blank')}>Gerar PDF</button></div><div className="kv"><div><span>Valor original</span><strong>{money(a.originalValue)}</strong></div><div><span>Valor em aberto</span><strong>{money(a.totalFinal)}</strong></div><div><span>Juros diário</span><strong>{Number(a.dailyInterestRate)}%</strong></div><div><span>Valor atualizado</span><strong>{money(daily.updated)}</strong></div><div><span>Início do juros</span><strong>{a.dailyInterestStartedAt ? dateBR(a.dailyInterestStartedAt) : 'Não iniciado'}</strong></div><div><span>Dias de juros</span><strong>{daily.days}</strong></div><div><span>Juros acumulado</span><strong>{money(daily.accumulated)}</strong></div><div><span>Parcela</span><strong>{money(a.installmentValue)}</strong></div></div><p>{a.notes || ''}</p><div className="tableWrap"><table><thead><tr><th>Nº</th><th>Parcela</th><th>Juros</th><th>Amortização</th><th>Saldo</th><th>Vencimento</th></tr></thead><tbody>{a.installments?.map(i => <tr key={i.id || i.number}><td>{i.number}</td><td>{money(i.value)}</td><td>{money(i.interest)}</td><td>{money(i.amortization)}</td><td>{money(i.balance)}</td><td>{dateBR(i.dueDate)}</td></tr>)}</tbody></table></div></div>; })}{!agreements.length && <div className="empty card">Nenhum relatório disponível para você.</div>}</div>;
}

function MyData({ user }) {
  return <div className="card"><h2>Meus dados</h2><div className="kv"><div><span>Nome</span><strong>{user?.client?.name || user?.name}</strong></div><div><span>E-mail/Login</span><strong>{user?.email}</strong></div><div><span>CPF/CNPJ</span><strong>{user?.client?.cpfCnpj || '-'}</strong></div><div><span>Telefone</span><strong>{user?.client?.phone || '-'}</strong></div></div><p>Para alterar seus dados, entre em contato com o administrador.</p></div>;
}

export default function ClientPage() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [menu, setMenu] = useState('Solicitar valor');
  const [message, setMessage] = useState('');
  const [agreements, setAgreements] = useState([]);

  async function load() {
    const session = await fetch('/api/session').then(r => r.json());
    if (!session.user || session.user.role !== 'CLIENT') return router.push('/login');
    setUser(session.user);
    const reports = await fetch('/api/agreements').then(r => r.json());
    setAgreements(reports.agreements || []);
  }
  async function logout() { await fetch('/api/auth/logout', { method: 'POST' }); router.push('/login'); }
  useEffect(() => { load(); }, []);

  const content = useMemo(() => {
    if (menu === 'Solicitar valor') return <RequestValue setMessage={setMessage} />;
    if (menu === 'Meus relatórios') return <Reports agreements={agreements} />;
    return <MyData user={user} />;
  }, [menu, agreements, user]);

  return <main className="shell"><Sidebar menu={menu} setMenu={setMenu} user={user} logout={logout} /><section className="content"><div className="topbar"><div><h1>{menu}</h1><p>Área do cliente. Você só visualiza suas próprias informações.</p></div>{message && <div className="message success">{message}</div>}</div>{content}</section></main>;
}
