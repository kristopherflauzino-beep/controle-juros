'use client';

import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';

const money = value => Number(value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const dateBR = value => value ? new Date(value).toLocaleDateString('pt-BR') : '-';
const todayInput = () => new Date().toISOString().slice(0, 10);

function calcDaily(totalFinal, dailyRate, startedAt) {
  const value = Number(totalFinal || 0);
  const rate = Number(dailyRate || 0);
  if (!startedAt || rate <= 0) return { days: 0, accumulated: 0, updated: value };
  const days = Math.max(0, Math.floor((Date.now() - new Date(startedAt).getTime()) / 86400000));
  const updated = value * Math.pow(1 + rate / 100, days);
  return { days, accumulated: updated - value, updated };
}

function Sidebar({ menu, setMenu, user, logout }) {
  const items = ['Dashboard', 'Clientes', 'Solicitações', 'Calculadora', 'Relatórios', 'Configurações'];
  return <aside className="sidebar">
    <div className="brand"><div className="logoMark small">CJ</div><div><strong>Controle de Juros</strong><span>Painel administrativo</span></div></div>
    <nav>{items.map(item => <button key={item} className={menu === item ? 'active' : ''} onClick={() => setMenu(item)}>{item}</button>)}<button onClick={logout}>Sair</button></nav>
    <div className="userBox"><strong>{user?.name}</strong><span>{user?.email}</span><span>ADMIN</span></div>
  </aside>;
}

function Dashboard({ summary, load }) {
  useEffect(() => { load(); }, []);
  const cards = [
    ['Total de clientes', summary?.totalClients || 0],
    ['Solicitações pendentes', summary?.pendingRequests || 0],
    ['Total em aberto', money(summary?.totalOpen || 0)],
    ['Total atualizado com juros', money(summary?.totalUpdated || 0)],
    ['Relatórios em atraso', summary?.lateReports || 0]
  ];
  return <>
    <div className="gridCards">{cards.map(([label, value]) => <div className="stat" key={label}><span>{label}</span><strong>{value}</strong></div>)}</div>
    <div className="card"><h2>Últimas solicitações</h2><div className="tableWrap"><table><thead><tr><th>Cliente</th><th>Valor</th><th>Status</th><th>Data</th><th>Observação</th></tr></thead><tbody>{summary?.latestRequests?.map(item => <tr key={item.id}><td>{item.client?.name}</td><td>{money(item.amount)}</td><td><span className={`badge badge-${String(item.status).toLowerCase()}`}>{item.status}</span></td><td>{dateBR(item.createdAt)}</td><td>{item.observation || '-'}</td></tr>)}</tbody></table></div></div>
  </>;
}

function Clients({ clients, loadClients, setMessage }) {
  const empty = { name: '', cpfCnpj: '', phone: '', email: '', password: '', active: true };
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState(null);

  async function save(e) {
    e.preventDefault();
    const payload = { ...form, active: form.active !== false };
    const url = editing ? `/api/admin/clients/${editing}` : '/api/admin/clients';
    const method = editing ? 'PUT' : 'POST';
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const data = await res.json();
    if (!res.ok) return setMessage(data.error || 'Erro ao salvar cliente.');
    setMessage('Cliente salvo com sucesso.');
    setForm(empty); setEditing(null); loadClients();
  }

  async function remove(id) {
    if (!confirm('Remover cliente e seus dados?')) return;
    const res = await fetch(`/api/admin/clients/${id}`, { method: 'DELETE' });
    if (res.ok) { setMessage('Cliente removido.'); loadClients(); }
  }

  function edit(c) {
    setEditing(c.id);
    setForm({ name: c.name, cpfCnpj: c.cpfCnpj || '', phone: c.phone || '', email: c.email, password: '', active: c.active });
  }

  return <div className="panel twoCols">
    <div className="card"><h2>{editing ? 'Editar cliente' : 'Cadastrar cliente'}</h2><form className="formGrid" onSubmit={save}>
      <label className="field"><span>Nome</span><input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required /></label>
      <label className="field"><span>CPF/CNPJ opcional</span><input value={form.cpfCnpj} onChange={e => setForm({ ...form, cpfCnpj: e.target.value })} /></label>
      <label className="field"><span>Telefone opcional</span><input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></label>
      <label className="field"><span>E-mail/Login</span><input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required /></label>
      <label className="field"><span>{editing ? 'Nova senha opcional' : 'Senha inicial'}</span><input type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} required={!editing} /></label>
      <label className="field"><span>Status</span><select value={form.active ? 'true' : 'false'} onChange={e => setForm({ ...form, active: e.target.value === 'true' })}><option value="true">Ativo</option><option value="false">Desativado</option></select></label>
      <button className="primary">{editing ? 'Salvar alterações' : 'Cadastrar cliente'}</button>
      {editing && <button type="button" className="ghost" onClick={() => { setEditing(null); setForm(empty); }}>Cancelar edição</button>}
    </form></div>
    <div className="card"><h2>Clientes</h2><div className="tableWrap"><table><thead><tr><th>Nome</th><th>Login</th><th>Telefone</th><th>Status</th><th>Ações</th></tr></thead><tbody>{clients.map(c => <tr key={c.id}><td>{c.name}</td><td>{c.email}</td><td>{c.phone || '-'}</td><td>{c.active ? 'Ativo' : 'Desativado'}</td><td className="actions"><button onClick={() => edit(c)}>Editar</button><button className="danger" onClick={() => remove(c.id)}>Remover</button></td></tr>)}</tbody></table></div></div>
  </div>;
}

function Requests({ requests, loadRequests, loadAgreements, setMessage }) {
  const [approve, setApprove] = useState(null);
  const [form, setForm] = useState({ originalValue: '', installmentsCount: 1, interestRate: 0, dailyInterestRate: 0, dueDate: todayInput(), notes: '' });
  function openApprove(r) { setApprove(r); setForm({ originalValue: r.amount, installmentsCount: 1, interestRate: 0, dailyInterestRate: 0, dueDate: todayInput(), notes: r.observation || '' }); }
  async function reject(id) {
    const res = await fetch(`/api/requests/${id}/reject`, { method: 'POST' });
    if (res.ok) { setMessage('Solicitação recusada.'); loadRequests(); }
  }
  async function submitApprove(e) {
    e.preventDefault();
    const res = await fetch(`/api/requests/${approve.id}/approve`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
    const data = await res.json();
    if (!res.ok) return setMessage(data.error || 'Erro ao aprovar.');
    setMessage('Solicitação aprovada e transformada em relatório.');
    setApprove(null); loadRequests(); loadAgreements();
  }
  return <div className="card"><h2>Solicitações dos clientes</h2><div className="tableWrap"><table><thead><tr><th>Cliente</th><th>Valor</th><th>Data</th><th>Observação</th><th>Status</th><th>Ações</th></tr></thead><tbody>{requests.map(r => <tr key={r.id}><td>{r.client?.name}</td><td>{money(r.amount)}</td><td>{dateBR(r.createdAt)}</td><td>{r.observation || '-'}</td><td><span className={`badge badge-${String(r.status).toLowerCase()}`}>{r.status}</span></td><td className="actions">{r.status === 'PENDENTE' && <><button className="success" onClick={() => openApprove(r)}>Aprovar</button><button className="danger" onClick={() => reject(r.id)}>Recusar</button></>}</td></tr>)}</tbody></table></div>
  {approve && <div className="modalOverlay"><div className="modalBox"><h2>Aprovar solicitação</h2><form className="formGrid two" onSubmit={submitApprove}>
    <label className="field"><span>Valor original</span><input type="number" min="0.01" step="0.01" value={form.originalValue} onChange={e => setForm({ ...form, originalValue: e.target.value })} required /></label>
    <label className="field"><span>Parcelas</span><input type="number" min="1" value={form.installmentsCount} onChange={e => setForm({ ...form, installmentsCount: e.target.value })} required /></label>
    <label className="field"><span>Juros por período (%)</span><input type="number" min="0" step="0.0001" value={form.interestRate} onChange={e => setForm({ ...form, interestRate: e.target.value })} /></label>
    <label className="field"><span>Juros diário (%)</span><input type="number" min="0" step="0.0001" value={form.dailyInterestRate} onChange={e => setForm({ ...form, dailyInterestRate: e.target.value })} /></label>
    <label className="field"><span>Vencimento</span><input type="date" value={form.dueDate} onChange={e => setForm({ ...form, dueDate: e.target.value })} required /></label>
    <label className="field full"><span>Observações</span><textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} /></label>
    <button className="primary">Aprovar e criar relatório</button><button type="button" className="ghost" onClick={() => setApprove(null)}>Cancelar</button>
  </form></div></div>}
  </div>;
}

function Calculator() {
  const [form, setForm] = useState({ principal: 1000, rate: 2, installments: 12, firstDueDate: todayInput() });
  const [result, setResult] = useState(null);
  const [message, setMessage] = useState('');
  async function calculate(e) {
    e.preventDefault(); setMessage('');
    const res = await fetch('/api/calculator/price', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
    const data = await res.json();
    if (!res.ok) return setMessage(data.error || 'Erro no cálculo.');
    setResult(data);
  }
  return <div className="reports"><div className="card"><h2>Calculadora Tabela Price</h2><form className="formGrid four" onSubmit={calculate}>
    <label className="field"><span>Valor financiado</span><input type="number" min="0.01" step="0.01" value={form.principal} onChange={e => setForm({ ...form, principal: e.target.value })} /></label>
    <label className="field"><span>Taxa de juros (%)</span><input type="number" min="0" step="0.0001" value={form.rate} onChange={e => setForm({ ...form, rate: e.target.value })} /></label>
    <label className="field"><span>Parcelas</span><input type="number" min="1" value={form.installments} onChange={e => setForm({ ...form, installments: e.target.value })} /></label>
    <label className="field"><span>Primeiro vencimento</span><input type="date" value={form.firstDueDate} onChange={e => setForm({ ...form, firstDueDate: e.target.value })} /></label>
    <button className="primary">Calcular</button>
  </form>{message && <div className="message error">{message}</div>}</div>
  {result && <div className="card"><div className="gridCards"><div className="stat"><span>Parcela</span><strong>{money(result.installmentValue)}</strong></div><div className="stat"><span>Total final</span><strong>{money(result.totalFinal)}</strong></div><div className="stat"><span>Total de juros</span><strong>{money(result.totalInterest)}</strong></div><div className="stat"><span>Parcelas</span><strong>{result.installments}</strong></div></div><div className="tableWrap"><table><thead><tr><th>Nº</th><th>Parcela</th><th>Juros</th><th>Amortização</th><th>Saldo devedor</th></tr></thead><tbody>{result.table.map(i => <tr key={i.number}><td>{i.number}</td><td>{money(i.value)}</td><td>{money(i.interest)}</td><td>{money(i.amortization)}</td><td>{money(i.balance)}</td></tr>)}</tbody></table></div></div>}
  </div>;
}

function Reports({ clients, agreements, loadAgreements, setMessage }) {
  const empty = { clientId: '', originalValue: '', installmentsCount: 1, interestRate: 0, dailyInterestRate: 0, dueDate: todayInput(), notes: '', status: 'ABERTO' };
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState(null);
  const [filter, setFilter] = useState('');
  const shown = agreements.filter(a => !filter || a.clientId === filter);

  function edit(a) {
    setEditing(a.id);
    setForm({ clientId: a.clientId, originalValue: a.originalValue, installmentsCount: a.installmentsCount, interestRate: a.interestRate, dailyInterestRate: a.dailyInterestRate, dueDate: String(a.dueDate).slice(0,10), notes: a.notes || '', status: a.status });
  }
  async function save(e) {
    e.preventDefault();
    const res = await fetch(editing ? `/api/agreements/${editing}` : '/api/agreements', { method: editing ? 'PUT' : 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
    const data = await res.json();
    if (!res.ok) return setMessage(data.error || 'Erro ao salvar relatório.');
    setMessage('Relatório salvo com sucesso.'); setForm(empty); setEditing(null); loadAgreements();
  }
  async function startInterest(id) {
    const res = await fetch(`/api/agreements/${id}/start-interest`, { method: 'POST' });
    const data = await res.json();
    if (!res.ok) return setMessage(data.error || 'Erro ao iniciar juros.');
    setMessage('Juros diário iniciado.'); loadAgreements();
  }
  async function remove(id) {
    if (!confirm('Remover relatório?')) return;
    const res = await fetch(`/api/agreements/${id}`, { method: 'DELETE' });
    if (res.ok) { setMessage('Relatório removido.'); loadAgreements(); }
  }
  function download(url) { window.open(url, '_blank'); }

  return <div className="reports">
    <div className="card"><h2>{editing ? 'Editar relatório' : 'Criar relatório/acordo'}</h2><form className="formGrid four" onSubmit={save}>
      <label className="field"><span>Cliente</span><select value={form.clientId} onChange={e => setForm({ ...form, clientId: e.target.value })} required><option value="">Selecione</option>{clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
      <label className="field"><span>Valor</span><input type="number" min="0.01" step="0.01" value={form.originalValue} onChange={e => setForm({ ...form, originalValue: e.target.value })} required /></label>
      <label className="field"><span>Parcelas</span><input type="number" min="1" value={form.installmentsCount} onChange={e => setForm({ ...form, installmentsCount: e.target.value })} required /></label>
      <label className="field"><span>Taxa de juros (%)</span><input type="number" min="0" step="0.0001" value={form.interestRate} onChange={e => setForm({ ...form, interestRate: e.target.value })} /></label>
      <label className="field"><span>Juros diário (%)</span><input type="number" min="0" step="0.0001" value={form.dailyInterestRate} onChange={e => setForm({ ...form, dailyInterestRate: e.target.value })} /></label>
      <label className="field"><span>Vencimento</span><input type="date" value={form.dueDate} onChange={e => setForm({ ...form, dueDate: e.target.value })} required /></label>
      <label className="field"><span>Status</span><select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}><option>ABERTO</option><option>PAGO</option><option>ATRASADO</option><option>CANCELADO</option></select></label>
      <label className="field full"><span>Observações</span><textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} /></label>
      <button className="primary">{editing ? 'Salvar edição' : 'Criar relatório'}</button>{editing && <button type="button" className="ghost" onClick={() => { setEditing(null); setForm(empty); }}>Cancelar edição</button>}
    </form></div>
    <div className="toolbar"><div><h2>Relatórios</h2><p>Filtre por cliente ou gere PDFs.</p></div><div className="toolbarActions"><select value={filter} onChange={e => setFilter(e.target.value)}><option value="">Todos os clientes</option>{clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select><button onClick={() => download(filter ? `/api/reports/pdf?clientId=${filter}` : '/api/reports/pdf')}>PDF {filter ? 'do cliente' : 'geral'}</button></div></div>
    {shown.map(a => { const daily = calcDaily(a.totalFinal, a.dailyInterestRate, a.dailyInterestStartedAt); return <div className="card" key={a.id}><div className="reportHeader"><div><h2>{a.client?.name}</h2><span className={`badge badge-${String(a.status).toLowerCase()}`}>{a.status}</span></div><div className="actions"><button onClick={() => edit(a)}>Editar</button><button className="success" onClick={() => startInterest(a.id)} disabled={Boolean(a.dailyInterestStartedAt)}>Iniciar juros diário</button><button onClick={() => download(`/api/agreements/${a.id}/pdf`)}>Gerar PDF</button><button className="danger" onClick={() => remove(a.id)}>Remover</button></div></div><div className="kv"><div><span>Valor original</span><strong>{money(a.originalValue)}</strong></div><div><span>Valor em aberto</span><strong>{money(a.totalFinal)}</strong></div><div><span>Juros diário</span><strong>{Number(a.dailyInterestRate)}%</strong></div><div><span>Valor atualizado</span><strong>{money(daily.updated)}</strong></div><div><span>Início do juros</span><strong>{a.dailyInterestStartedAt ? dateBR(a.dailyInterestStartedAt) : 'Não iniciado'}</strong></div><div><span>Dias de juros</span><strong>{daily.days}</strong></div><div><span>Juros acumulado</span><strong>{money(daily.accumulated)}</strong></div><div><span>Parcela</span><strong>{money(a.installmentValue)}</strong></div></div><p>{a.notes || ''}</p><div className="tableWrap"><table><thead><tr><th>Nº</th><th>Parcela</th><th>Juros</th><th>Amortização</th><th>Saldo</th><th>Vencimento</th></tr></thead><tbody>{a.installments?.map(i => <tr key={i.id || i.number}><td>{i.number}</td><td>{money(i.value)}</td><td>{money(i.interest)}</td><td>{money(i.amortization)}</td><td>{money(i.balance)}</td><td>{dateBR(i.dueDate)}</td></tr>)}</tbody></table></div></div>; })}
    {!shown.length && <div className="empty card">Nenhum relatório encontrado.</div>}
  </div>;
}

function Settings({ user }) {
  return <div className="card"><h2>Configurações</h2><p>Usuário autenticado: <strong>{user?.name}</strong></p><p>Configure no Vercel as variáveis <strong>DATABASE_URL</strong> e <strong>JWT_SECRET</strong>.</p><p>A rota de teste do deploy é <strong>/api/health</strong>.</p></div>;
}

export default function AdminPage() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [menu, setMenu] = useState('Dashboard');
  const [message, setMessage] = useState('');
  const [summary, setSummary] = useState(null);
  const [clients, setClients] = useState([]);
  const [requests, setRequests] = useState([]);
  const [agreements, setAgreements] = useState([]);

  async function loadSession() {
    const data = await fetch('/api/session').then(r => r.json());
    if (!data.user || data.user.role !== 'ADMIN') return router.push('/login');
    setUser(data.user);
  }
  const loadSummary = () => fetch('/api/admin/summary').then(r => r.json()).then(setSummary).catch(() => {});
  const loadClients = () => fetch('/api/admin/clients').then(r => r.json()).then(d => setClients(d.clients || [])).catch(() => {});
  const loadRequests = () => fetch('/api/requests').then(r => r.json()).then(d => setRequests(d.requests || [])).catch(() => {});
  const loadAgreements = () => fetch('/api/agreements').then(r => r.json()).then(d => setAgreements(d.agreements || [])).catch(() => {});
  async function logout() { await fetch('/api/auth/logout', { method: 'POST' }); router.push('/login'); }

  useEffect(() => { loadSession(); loadSummary(); loadClients(); loadRequests(); loadAgreements(); }, []);
  const title = menu;
  const content = useMemo(() => {
    if (menu === 'Dashboard') return <Dashboard summary={summary} load={loadSummary} />;
    if (menu === 'Clientes') return <Clients clients={clients} loadClients={loadClients} setMessage={setMessage} />;
    if (menu === 'Solicitações') return <Requests requests={requests} loadRequests={loadRequests} loadAgreements={loadAgreements} setMessage={setMessage} />;
    if (menu === 'Calculadora') return <Calculator />;
    if (menu === 'Relatórios') return <Reports clients={clients} agreements={agreements} loadAgreements={loadAgreements} setMessage={setMessage} />;
    return <Settings user={user} />;
  }, [menu, summary, clients, requests, agreements, user]);

  return <main className="shell"><Sidebar menu={menu} setMenu={setMenu} user={user} logout={logout} /><section className="content"><div className="topbar"><div><h1>{title}</h1><p>Gestão administrativa do Controle de Juros.</p></div>{message && <div className={`message ${message.toLowerCase().includes('erro') ? 'error' : 'success'}`}>{message}</div>}</div>{content}</section></main>;
}
