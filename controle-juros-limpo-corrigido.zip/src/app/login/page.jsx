'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const router = useRouter();
  const [form, setForm] = useState({ email: '', password: '' });
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [firstAccessAvailable, setFirstAccessAvailable] = useState(false);

  useEffect(() => {
    fetch('/api/auth/first-access').then(r => r.json()).then(data => setFirstAccessAvailable(Boolean(data.available))).catch(() => {});
  }, []);

  async function submit(e) {
    e.preventDefault();
    setLoading(true);
    setMessage('');
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    });
    const data = await response.json();
    setLoading(false);
    if (!response.ok) {
      setMessage(data.error || 'Erro ao entrar.');
      return;
    }
    router.push(data.redirectTo);
  }

  return (
    <main className="authPage">
      <section className="authBrand">
        <div className="logoMark">CJ</div>
        <h1>Controle de Juros</h1>
        <p>Sistema profissional para clientes, solicitações, acordos, Tabela Price, juros diário composto e relatórios em PDF.</p>
        <div className="authFeatures">
          <span>Tabela Price</span>
          <span>Juros diário</span>
          <span>PDF profissional</span>
          <span>Admin e cliente</span>
        </div>
      </section>
      <section className="authCard">
        <h2>Entrar no sistema</h2>
        <p>Use seu login e senha cadastrados.</p>
        <form className="formGrid" onSubmit={submit}>
          <label className="field"><span>E-mail/Login</span><input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required /></label>
          <label className="field"><span>Senha</span><input type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} required /></label>
          <button className="primary" disabled={loading}>{loading ? 'Entrando...' : 'Entrar'}</button>
        </form>
        {message && <div className="message error">{message}</div>}
        {firstAccessAvailable && <p style={{ marginTop: 18 }}>Primeiro uso? <Link href="/first-access">Cadastrar administrador</Link></p>}
      </section>
    </main>
  );
}
