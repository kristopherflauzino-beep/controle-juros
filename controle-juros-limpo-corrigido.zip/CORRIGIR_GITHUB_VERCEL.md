# Correção do erro da Vercel

O repositório antigo estava com arquivos trocados:

- `package.json` tinha CSS dentro.
- `next.config.js` tinha código de banco/store.
- `vercel.json` tinha texto de README e não JSON.

Esta versão não tem `vercel.json`.

## Como subir esta versão limpa

1. Extraia este ZIP em uma pasta nova.
2. Abra o terminal dentro da pasta extraída.
3. Execute:

```bat
publicar_github.bat
```

O script envia para:

```text
https://github.com/kristopherflauzino-beep/controle-juros.git
```

E atualiza as branches:

```text
principal
main
```

Isso evita que a Vercel continue usando o código quebrado antigo.
