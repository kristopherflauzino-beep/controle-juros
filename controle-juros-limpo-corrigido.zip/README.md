# Controle de Juros

Aplicação web completa em Next.js para controle de clientes, solicitações, acordos, Tabela Price, juros diário composto e geração de PDF.

## Importante

Este projeto foi criado limpo do zero. Não existe `vercel.json`, porque a Vercel detecta Next.js automaticamente.

## Requisitos

- Node.js 20 ou superior
- Banco PostgreSQL compatível com Vercel
- Variáveis de ambiente:
  - `DATABASE_URL`
  - `JWT_SECRET`

## Rodar localmente

```bash
npm install
copy .env.example .env
npx prisma db push
npm run dev
```

Acesse:

```text
http://localhost:3000
```

## Primeiro acesso

Abra:

```text
/first-access
```

Cadastre o administrador e depois entre em:

```text
/login
```

## Testar build

```bash
npm install
npm run build
```

## API de saúde

```text
/api/health
```

Retorno esperado:

```json
{"status":"OK"}
```

## Publicação no GitHub

Execute no Windows:

```bat
publicar_github.bat
```

O script envia para:

```text
https://github.com/kristopherflauzino-beep/controle-juros
```

Branch principal:

```text
principal
```

O script também sincroniza `main` para evitar que a Vercel continue compilando código antigo caso o projeto esteja apontado para `main`.
