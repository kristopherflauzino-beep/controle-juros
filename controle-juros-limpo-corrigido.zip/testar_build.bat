@echo off
chcp 65001 >nul
echo Testando build do Controle de Juros...
npm install
if errorlevel 1 exit /b 1
npm run build
if errorlevel 1 (
  echo ERRO: build falhou.
  pause
  exit /b 1
)
echo Build concluido com sucesso.
pause
