@echo off
chcp 65001 >nul
echo Publicando Controle de Juros no GitHub...
echo ATENCAO: este script sobrescreve as branches principal e main com esta versao limpa.

npm install
if errorlevel 1 (
  echo ERRO: npm install falhou.
  pause
  exit /b 1
)

npm run build
if errorlevel 1 (
  echo ERRO: npm run build falhou. Corrija antes de publicar.
  pause
  exit /b 1
)

git init
git checkout -B principal
git remote remove origin 2>nul
git remote add origin https://github.com/kristopherflauzino-beep/controle-juros.git
git add .
git commit -m "Versao limpa Controle de Juros"

git push -u origin principal --force
if errorlevel 1 (
  echo ERRO: falha ao enviar para branch principal.
  pause
  exit /b 1
)

git push origin principal:main --force
if errorlevel 1 (
  echo AVISO: nao consegui sincronizar a branch main. Verifique permissoes no GitHub.
)

echo Publicacao concluida.
echo Na Vercel, use a branch principal ou main; as duas foram sincronizadas com o codigo limpo.
pause
