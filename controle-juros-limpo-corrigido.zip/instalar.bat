@echo off
chcp 65001 >nul
echo Instalando dependencias do Controle de Juros...
npm install
if errorlevel 1 (
  echo ERRO: npm install falhou.
  pause
  exit /b 1
)
echo Gerando Prisma Client...
npx prisma generate
if errorlevel 1 (
  echo ERRO: prisma generate falhou.
  pause
  exit /b 1
)
echo Pronto.
pause
